package com.clases.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabricGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
